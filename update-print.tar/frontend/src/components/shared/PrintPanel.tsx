import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Printer, X, Globe, Sparkles, AlertTriangle, RefreshCw, FileText, ScrollText, Search, Plus } from 'lucide-react';
import toast from 'react-hot-toast';
import { usePrintPanel, getQuickPrint, setQuickPrint } from '../../lib/printPanel';
import { layoutDocument, printSrcdoc, type Fit, type LayoutResult, type Orient, type Paper } from '../../lib/print';
import { impresionService, type EstadoImpresora, type HostEncontrado, type UsoImpresora } from '../../services/impresion.service';
import { getDevicePrinter } from '../../lib/printClient';
import { printLang, apiError } from '../../i18n';
import { useAuthStore } from '../../store/authStore';
import { isAdminLike } from '../../auth/permissions';
import { cn } from '../../utils/cn';
import { t } from '../../i18n';

const PX_PER_MM = 96 / 25.4;
const USO: Record<string, UsoImpresora> = { recibo: 'RECIBO', cuenta: 'CUENTA', cocina: 'COCINA', cierre: 'REPORTE' };
const ROLLS = [58, 80, 90];

const Seg = <T extends string | number>({ value, onChange, options }: { value: T; onChange: (v: T) => void; options: { v: T; label: string }[] }) => (
  <div className="inline-flex rounded-m border border-border overflow-hidden bg-muted">
    {options.map((o) => (
      <button key={String(o.v)} type="button" data-sound="none" onClick={() => onChange(o.v)}
        className={cn('px-3 py-1.5 text-sm font-medium transition-colors', o.v === value ? 'bg-primary text-white' : 'text-muted-foreground hover:text-foreground')}>
        {o.label}
      </button>
    ))}
  </div>
);

/** Собственное окно печати: предпросмотр, умный выбор принтера, подгонка размера. Заменяет окно печати браузера. */
export function PrintPanel() {
  const { job, close } = usePrintPanel();
  const [target, setTarget] = useState<string>('browser');     // 'auto' | id принтера | 'browser'
  const [paper, setPaper] = useState<Paper>('A4');
  const [fit, setFit] = useState<Fit>('auto');
  const [orient, setOrient] = useState<Orient>('auto');
  const [layout, setLayout] = useState<LayoutResult | null>(null);
  const [busy, setBusy] = useState(false);
  const [errors, setErrors] = useState<string[]>([]);
  const [quick, setQuick] = useState(getQuickPrint());
  const box = useRef<HTMLDivElement>(null);
  const [boxSize, setBoxSize] = useState({ w: 320, h: 400 });
  const me = useAuthStore((s) => s.user);
  // быстрая настройка сетевого принтера прямо из окна печати
  const [ipText, setIpText] = useState('');
  const [scanning, setScanning] = useState(false);
  const [found, setFound] = useState<HostEncontrado[] | null>(null);
  const [setupMsg, setSetupMsg] = useState('');
  const autoDone = useRef<object | null>(null);

  const { data: estado = [], refetch, isFetching } = useQuery<EstadoImpresora[]>({
    queryKey: ['imprimirEstado'], queryFn: impresionService.estado, enabled: !!job?.server, refetchInterval: job ? 8000 : false, staleTime: 3000,
  });
  const eligible = useMemo(() => {
    if (!job?.server) return [];
    const uso = USO[job.server.tipo];
    return estado.filter((p) => p.tipo !== 'NAVEGADOR' && (p.usos.includes(uso) || estado.every((x) => !x.usos.includes(uso))));
  }, [estado, job]);
  const bestAuto = useMemo(() => [...eligible].filter((p) => p.online).sort((a, b) => a.ms - b.ms)[0], [eligible]);

  // начальные значения при открытии
  useEffect(() => {
    if (!job) return;
    setErrors([]); setBusy(false); setFit('auto'); setOrient('auto'); setPaper(job.paper);
    setTarget(job.server && !job.autoPrint ? 'auto' : 'browser');
    setFound(null); setSetupMsg('');
  }, [job]);

  // «умный» выбор: когда пришло состояние принтеров — закреплённый за устройством, иначе лучший онлайн, иначе браузер
  const picked = useRef<object | null>(null);
  useEffect(() => {
    if (!job?.server || picked.current === job || estado.length === 0) return;
    picked.current = job;
    const dev = getDevicePrinter();
    if (dev && eligible.some((p) => p.id === dev && p.online)) setTarget(dev);
    else setTarget(bestAuto ? 'auto' : 'browser');
  }, [job, estado, eligible, bestAuto]);
  useEffect(() => { if (!job) picked.current = null; }, [job]);

  const chosen: EstadoImpresora | undefined = target === 'auto' ? bestAuto : eligible.find((p) => p.id === target);
  const physical = target !== 'browser' && !!job?.server;
  // ширина ленты подстраивается под выбранный принтер
  useEffect(() => { if (chosen && typeof paper === 'number') setPaper(chosen.ancho); }, [chosen?.id]); // eslint-disable-line react-hooks/exhaustive-deps

  // раскладка (предпросмотр = то, что напечатается)
  useEffect(() => {
    if (!job) { setLayout(null); return; }
    let off = false;
    layoutDocument(job.html, job.title, { paper, fit, orient }).then((l) => { if (!off) setLayout(l); }).catch(() => undefined);
    return () => { off = true; };
  }, [job, paper, fit, orient]);

  useEffect(() => {
    if (!box.current) return;
    const ro = new ResizeObserver(([e]) => setBoxSize({ w: e.contentRect.width, h: e.contentRect.height }));
    ro.observe(box.current);
    return () => ro.disconnect();
  }, [job]);

  const printNow = useCallback(async () => {
    if (!job || busy) return;
    setBusy(true); setErrors([]);
    try {
      if (physical && job.server) {
        const r = await impresionService.imprimir({ ...job.server, impresoraId: target === 'auto' ? undefined : target, lang: printLang });
        const ok = r.resultados.find((x) => x.ok);
        if (ok) { toast.success(t('Impreso: {name}', { name: ok.impresora })); close(); return; }
        setErrors(r.resultados.map((x) => `${x.impresora}: ${t('No se pudo imprimir')}${x.detalle ? ' — ' + x.detalle : ''}`).concat(r.resultados.length ? [] : [t('No hay impresora configurada para reportes')]));
        void refetch();
        return;
      }
      if (!layout) return;
      await printSrcdoc(layout.srcdoc);
      close();
    } catch (e: any) {
      setErrors([e?.response?.status === 403 ? t('Sin permisos para esta acción') : t('No se pudo imprimir')]);
    } finally { setBusy(false); }
  }, [job, busy, physical, target, layout, close, refetch]);

  // чек после оплаты: печать стартует сама, как только документ готов
  useEffect(() => {
    if (!job?.autoPrint || !layout || autoDone.current === job) return;
    autoDone.current = job;
    void printNow();
  }, [job, layout, printNow]);

  useEffect(() => {
    if (!job) return;
    const key = (e: KeyboardEvent) => {
      if (e.key === 'Escape') { close(); }
      else if (e.key === 'Enter' && !(e.target as HTMLElement)?.closest('button,input,select,textarea')) { e.preventDefault(); void printNow(); }
    };
    document.addEventListener('keydown', key);
    return () => document.removeEventListener('keydown', key);
  }, [job, close, printNow]);


  const addPrinter = async (ip: string) => {
    try {
      const p = await impresionService.create({ nombre: `${t('Impresora')} ${ip}`, tipo: 'RED', host: ip, puerto: 9100, ancho: 80, codepage: 'cp866', usos: ['RECIBO', 'CUENTA'], corte: true, cajon: false, copias: 1, auto: true, activa: true });
      toast.success(t('Impresora añadida'));
      setFound(null); setIpText('');
      await refetch();
      setTarget(p.id);
    } catch (e) { setSetupMsg(apiError(e, 'Error al guardar')); }
  };
  const findPrinter = async () => {
    const v = ipText.trim();
    setSetupMsg(''); setFound(null);
    const full = /^\d{1,3}(\.\d{1,3}){3}$/.test(v);
    const net = /^\d{1,3}(\.\d{1,3}){2}$/.test(v) ? v : /^(\d{1,3}(?:\.\d{1,3}){2})\.\d{1,3}$/.exec(location.hostname)?.[1];
    setScanning(true);
    try {
      if (full) {
        const r = await impresionService.comprobar(v, 9100);
        if (r.alcanzable) await addPrinter(v); else setSetupMsg(t('{ip} no responde. Revisa el cable, la IP y que esté en la misma red.', { ip: v }));
      } else if (net) {
        const r = await impresionService.descubrir(net, 9100);
        setFound(r.hosts);
        if (r.hosts.length === 0) setSetupMsg(t('No se encontró ninguna impresora en {red}.x', { red: net }));
      } else setSetupMsg(t('Escribe la IP de la impresora o los tres primeros números de la red'));
    } catch (e) { setSetupMsg(apiError(e, 'No se pudo imprimir')); }
    finally { setScanning(false); }
  };

  if (!job) return null;

  const isRoll = typeof paper === 'number';
  const pw = (layout?.widthMm ?? (isRoll ? (paper as number) : 210)) * PX_PER_MM;
  const ph = (layout?.heightMm ?? 200) * PX_PER_MM;
  const s = layout ? Math.min(1.4, Math.max(0.2, layout.roll ? (boxSize.w - 32) / pw : Math.min((boxSize.w - 32) / pw, (boxSize.h - 32) / ph))) : 1;

  const dot = (p: EstadoImpresora) => (
    <span className={cn('inline-block w-2.5 h-2.5 rounded-full flex-shrink-0', p.online ? 'bg-green-500 shadow-[0_0_0_3px_rgba(34,197,94,.25)]' : 'bg-red-500')} />
  );
  const Option = ({ id, icon, title, sub, disabled }: { id: string; icon: React.ReactNode; title: React.ReactNode; sub?: React.ReactNode; disabled?: boolean }) => (
    <button type="button" data-sound="none" disabled={disabled} onClick={() => { setTarget(id); setErrors([]); }}
      className={cn('w-full flex items-center gap-3 text-left rounded-l border px-3 py-2.5 transition-colors',
        target === id ? 'border-primary bg-primary/10' : 'border-border bg-muted hover:border-muted-foreground/50', disabled && 'opacity-50 cursor-not-allowed')}>
      <span className={cn('flex-shrink-0', target === id ? 'text-primary' : 'text-muted-foreground')}>{icon}</span>
      <span className="min-w-0 flex-1"><span className="block text-sm font-semibold text-foreground truncate">{title}</span>{sub && <span className="block text-xs text-muted-foreground truncate">{sub}</span>}</span>
      {target === id && <span className="w-2 h-2 rounded-full bg-primary flex-shrink-0" />}
    </button>
  );
  const stateTxt = (p: EstadoImpresora) => `${p.online ? t('En línea') : t('Fuera de línea')}${p.online && p.ms ? ` · ${p.ms} ms` : ''}${p.papel === 'poco' ? ` · ${t('Papel: poco')}` : p.papel === 'sin' ? ` · ${t('Papel: se acabó')}` : ''}`;

  return (
    <div className="fixed inset-0 z-[80] flex items-stretch sm:items-center justify-center" role="dialog" aria-modal="true" aria-label={t('Imprimir')}>
      <div className="absolute inset-0 bg-black/65 backdrop-blur-sm fade-in" onClick={close} />
      <div className="relative bg-card border border-border sm:rounded-l shadow-2xl w-full sm:w-[min(1080px,96vw)] h-full sm:h-[min(760px,94vh)] flex flex-col pop-in overflow-hidden">
        <div className="flex items-center justify-between px-4 sm:px-5 py-3 border-b border-border flex-shrink-0">
          <div className="flex items-center gap-2 min-w-0">
            <Printer size={18} className="text-primary flex-shrink-0" />
            <h2 className="text-base font-semibold text-foreground truncate">{t('Imprimir')} — {job.title}</h2>
          </div>
          <button onClick={close} data-sound="none" aria-label={t('Cerrar')} className="p-2 -mr-2 rounded-full text-muted-foreground hover:text-foreground hover:bg-muted"><X size={20} /></button>
        </div>

        <div className="flex-1 min-h-0 flex flex-col lg:flex-row">
          {/* предпросмотр */}
          <div className="lg:flex-1 min-h-[34vh] lg:min-h-0 bg-muted/60 flex flex-col border-b lg:border-b-0 lg:border-r border-border">
            <div className="px-4 py-2 flex items-center justify-between text-xs text-muted-foreground">
              <span className="font-medium uppercase tracking-wide">{t('Vista previa')}</span>
              {layout && <span>{Math.round(layout.widthMm)} × {Math.round(layout.heightMm)} {t('mm')} · {t('escala')} {Math.round(layout.scale * 100)}%{layout.orient === 'landscape' ? ` · ${t('Horizontal')}` : ''}</span>}
            </div>
            <div ref={box} className="flex-1 min-h-0 overflow-auto p-4 flex justify-center items-start">
              {layout ? (
                <div style={{ width: pw * s, height: ph * s }} className="flex-shrink-0 shadow-xl ring-1 ring-black/10 bg-white">
                  <iframe title="preview" srcDoc={layout.srcdoc} sandbox="allow-same-origin"
                    style={{ width: pw, height: ph, transform: `scale(${s})`, transformOrigin: 'top left', border: 0, background: '#fff', display: 'block' }} />
                </div>
              ) : <div className="text-sm text-muted-foreground py-10">{t('Cargando...')}</div>}
            </div>
          </div>

          {/* настройки */}
          <div className="lg:w-[360px] flex-shrink-0 overflow-y-auto p-4 sm:p-5 space-y-5">
            <section>
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-sm font-semibold text-foreground">{t('Impresora')}</h3>
                {job.server && <button type="button" data-sound="none" onClick={() => refetch()} className="text-xs text-muted-foreground hover:text-foreground inline-flex items-center gap-1"><RefreshCw size={12} className={cn(isFetching && 'animate-spin')} />{t('Actualizar')}</button>}
              </div>
              <div className="space-y-2">
                {job.server && (
                  <Option id="auto" icon={<Sparkles size={18} />} title={t('Auto (inteligente)')}
                    sub={bestAuto ? `${bestAuto.nombre} · ${stateTxt(bestAuto)}` : estado.length ? t('Ninguna impresora responde: se usará el navegador') : t('No hay impresoras configuradas: se usará el diálogo del navegador.')} />
                )}
                {eligible.map((p) => (
                  <Option key={p.id} id={p.id} icon={dot(p)} title={p.nombre} sub={`${stateTxt(p)} · ${p.ancho} ${t('mm')}`} />
                ))}
                <Option id="browser" icon={<Globe size={18} />} title={t('Diálogo del sistema (navegador)')} sub={t('Cualquier impresora de Windows, A4 o rollo')} />
              </div>
            </section>

            {job.server && !isFetching && estado.length === 0 && (
              <section className="rounded-l border border-primary/40 bg-primary/5 p-3 space-y-2.5">
                <h3 className="text-sm font-semibold text-foreground">{t('Sin impresora configurada')}</h3>
                {isAdminLike(me?.rol) ? (
                  <>
                    <p className="text-xs text-muted-foreground">{t('Busca la impresora de red y añádela en un clic')}</p>
                    <div className="flex gap-2">
                      <input value={ipText} onChange={(e) => setIpText(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter') { e.stopPropagation(); void findPrinter(); } }}
                        placeholder={t('IP de la impresora o red (192.168.1)')} inputMode="decimal"
                        className="flex-1 min-w-0 bg-muted border border-border rounded-m px-3 py-2 text-sm text-foreground focus:outline-none focus:border-primary" />
                      <button type="button" data-sound="none" onClick={findPrinter} disabled={scanning}
                        className="px-3 rounded-m bg-primary text-white text-sm font-medium inline-flex items-center gap-1.5 disabled:opacity-60">
                        <Search size={14} className={cn(scanning && 'animate-pulse')} />{scanning ? t('Revisando 254 direcciones…') : t('Buscar en la red')}
                      </button>
                    </div>
                    {found && found.map((h) => (
                      <button key={h.ip} type="button" data-sound="none" onClick={() => addPrinter(h.ip)}
                        className="w-full flex items-center justify-between gap-2 rounded-m border border-border bg-card px-3 py-2 text-left hover:border-primary">
                        <span className="min-w-0"><span className="block text-sm font-semibold text-foreground">{h.ip}</span><span className="block text-xs text-muted-foreground truncate">{h.estado.escpos ? t('Impresora ESC/POS') : h.web ?? t('{ip} responde en el puerto 9100', { ip: h.ip })}</span></span>
                        <span className="text-xs text-primary font-medium inline-flex items-center gap-1 flex-shrink-0"><Plus size={13} />{t('Añadir y usar')}</span>
                      </button>
                    ))}
                    {setupMsg && <p className="text-xs text-error">{setupMsg}</p>}
                  </>
                ) : <p className="text-xs text-muted-foreground">{t('Pídele al administrador que añada la impresora en «Configuración → Impresoras».')}</p>}
              </section>
            )}

            {(target === 'browser' || !job.server) && (
              <section className="space-y-3">
                <h3 className="text-sm font-semibold text-foreground">{t('Papel')}</h3>
                <Seg<string> value={isRoll ? String(paper) : 'A4'} onChange={(v) => setPaper(v === 'A4' ? 'A4' : Number(v))}
                  options={[...ROLLS.map((r) => ({ v: String(r), label: `${r} ${t('mm')}` })), { v: 'A4', label: 'A4' }]} />
                <div className="flex flex-wrap gap-x-5 gap-y-3">
                  <div>
                    <p className="text-xs text-muted-foreground mb-1">{t('Ajuste de tamaño')}</p>
                    <Seg<Fit> value={fit} onChange={setFit} options={[{ v: 'auto', label: t('Auto') }, { v: 'width', label: t('Al ancho') }, { v: 'none', label: '100%' }]} />
                  </div>
                  {!isRoll && (
                    <div>
                      <p className="text-xs text-muted-foreground mb-1">{t('Orientación')}</p>
                      <Seg<Orient> value={orient} onChange={setOrient} options={[{ v: 'auto', label: t('Auto') }, { v: 'portrait', label: t('Vertical') }, { v: 'landscape', label: t('Horizontal') }]} />
                    </div>
                  )}
                </div>
                <p className="text-xs text-muted-foreground flex items-start gap-1.5">
                  {isRoll ? <ScrollText size={14} className="mt-0.5 flex-shrink-0" /> : <FileText size={14} className="mt-0.5 flex-shrink-0" />}
                  {isRoll ? t('La altura del rollo se calcula por el contenido; si las líneas no caben, la letra se reduce sola.') : t('Si la tabla es más ancha que la hoja, se reduce la escala o se gira la hoja automáticamente.')}
                </p>
              </section>
            )}

            {job.server && (
              <label className="flex items-start gap-2 text-sm text-foreground cursor-pointer">
                <input type="checkbox" className="accent-primary mt-0.5" checked={quick} onChange={(e) => { setQuick(e.target.checked); setQuickPrint(e.target.checked); }} />
                <span>{t('Imprimir directamente, sin esta ventana')}<span className="block text-xs text-muted-foreground">{t('Solo en este dispositivo. Los recibos saldrán al instante en la impresora elegida.')}</span></span>
              </label>
            )}

            {errors.length > 0 && (
              <div className="rounded-l border border-error/40 bg-error-bg p-3 text-sm text-error space-y-1">
                <p className="font-semibold flex items-center gap-1.5"><AlertTriangle size={14} />{t('No se pudo imprimir')}</p>
                {errors.map((e, i) => <p key={i} className="text-xs break-words">{e}</p>)}
                {job.server && <button type="button" onClick={() => { setTarget('browser'); setErrors([]); }} className="text-xs underline">{t('Imprimir con el diálogo del navegador')}</button>}
              </div>
            )}
          </div>
        </div>

        <div className="flex items-center gap-3 px-4 sm:px-5 py-3 border-t border-border flex-shrink-0 bg-card" style={{ paddingBottom: 'max(0.75rem, env(safe-area-inset-bottom))' }}>
          <button onClick={close} data-sound="none" className="px-4 py-2.5 rounded-m bg-muted border border-border text-sm font-medium text-foreground hover:bg-border">{t('Cancelar')}</button>
          <button onClick={printNow} disabled={busy || (!layout && !physical)} data-sound="none"
            className="flex-1 flex items-center justify-center gap-2 px-4 py-2.5 rounded-m bg-primary text-white text-sm font-semibold hover:opacity-90 disabled:opacity-50">
            <Printer size={16} className={cn(busy && 'animate-pulse')} />
            {busy ? t('Imprimiendo...') : physical ? `${t('Imprimir')}${chosen ? ` · ${chosen.nombre}` : ''}` : t('Imprimir')}
          </button>
        </div>
      </div>
    </div>
  );
}
